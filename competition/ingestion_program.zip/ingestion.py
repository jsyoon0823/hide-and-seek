#!/usr/bin/env python3

import argparse
import docker
import flask
import functools
import glob
import gym
import json
import multiprocessing
import os
import requests
import subprocess
import sys
import tempfile
import threading
import time
import tqdm
import urllib


NB_EPISODES = 10
MAX_EPISODE_STEPS = 100
TIMEOUT = 6 * 3600  # 6 hours
PORT = 29592
DEFAULT_IMAGE = "tavianator/textworld-codalab"


def _docker_pull(client, image):
    split = image.split(":")
    if len(split) > 1:
        image, tag = split
    else:
        tag = "latest"
    client.images.pull(image, tag)


def _dockerize_agent(args, client, image, runtime):
    submission_dir = os.path.abspath(args.submission_dir)
    self_file = os.path.abspath(__file__)

    volumes = {
        submission_dir: {
            "bind": "/usr/src/submission",
            "mode": "ro",
        },
        self_file: {
            "bind": "/usr/bin/ingestion.py",
            "mode": "ro",
        },
    }

    environment = {
        "PYTHONUNBUFFERED": "1",
    }

    command = [
        "python3",
        "/usr/bin/ingestion.py",
        "--in-docker",
        "--listen={}".format(PORT),
        "/usr/src/submission",
        "/dev/null",
    ]

    if args.debug:
        command += ["--debug"]

    if args.nb_processes:
        command += ["--nb-processes", str(args.nb_processes)]

    _docker_pull(client, image)
    return client.containers.run(
        image,
        command,
        runtime=runtime,
        detach=True,
        network="textworld",
        volumes=volumes,
        environment=environment,
    )


def _dockerize_evaluator(args, client, host, runtime):
    games_dir = os.path.abspath(args.games_dir)
    output_file = os.path.abspath(args.output)
    self_file = os.path.abspath(__file__)

    volumes = {
        games_dir: {
            "bind": "/usr/share/textworld-games",
            "mode": "ro",
        },
        output_file: {
            "bind": "/usr/share/textworld-stats.json",
            "mode": "rw",
        },
        self_file: {
            "bind": "/usr/bin/ingestion.py",
            "mode": "ro",
        },
    }

    environment = {
        "PYTHONUNBUFFERED": "1",
    }

    command = [
        "python3",
        "/usr/bin/ingestion.py",
        "--in-docker",
        "--remote={}".format(host),
        "/dev/null",
        "/usr/share/textworld-games",
        "/usr/share/textworld-stats.json",
    ]

    if args.debug:
        command += ["--debug"]

    if args.nb_processes:
        command += ["--nb-processes", str(args.nb_processes)]

    _docker_pull(client, DEFAULT_IMAGE)
    return client.containers.run(
        DEFAULT_IMAGE,
        command,
        runtime=runtime,
        detach=True,
        network="textworld",
        volumes=volumes,
        environment=environment,
    )


def _dockerize(args):
    client = docker.from_env()

    info = client.info()
    if "nvidia" in info["Runtimes"]:
        runtime = "nvidia"
    else:
        runtime = info["DefaultRuntime"]

    # If it doesn't exist already, create a docker network with no internet access
    try:
        client.networks.create("textworld", internal=True, check_duplicate=True)
    except docker.errors.APIError as e:
        # HTTP 409: Conflict, aka the network already existed
        if e.status_code != 409:
            raise

    image_path = os.path.join(args.submission_dir, "Dockerimage")
    if os.path.exists(image_path):
        with open(image_path, "r") as f:
            image = f.read().strip()
    else:
        image = DEFAULT_IMAGE

    # Make sure the stats file exists so Docker doesn't create it as a directory
    open(args.output, "w").close()

    print("Loading {}...".format(image))
    agent = _dockerize_agent(args, client, image, runtime)
    evaluator = None

    try:
        agent.reload()
        host = agent.attrs["NetworkSettings"]["Networks"]["textworld"]["IPAddress"]
        host = "{}:{}".format(host, PORT)

        # HACK: Need to wait until the container web server is up
        time.sleep(10)
        print("Loading {}...".format(DEFAULT_IMAGE))
        evaluator = _dockerize_evaluator(args, client, host, runtime)
        print("Running {}...".format(image))
        for log in evaluator.logs(stream=True, follow=True):
            sys.stdout.buffer.write(log)
    finally:
        if evaluator:
            evaluator.stop()
        agent.stop()

        if args.verbose:
            sys.stdout.buffer.write(agent.logs(stdout=True, stderr=False))
            sys.stderr.buffer.write(agent.logs(stdout=False, stderr=True))

        if evaluator:
            evaluator.remove(force=True)
        agent.remove(force=True)

    print("Done")


def main():
    parser = argparse.ArgumentParser(description="Evaluate an agent.")
    parser.add_argument("--in-docker", action="store_true", default=False, help=argparse.SUPPRESS)
    parser.add_argument("--listen", type=int, default=None, help=argparse.SUPPRESS)
    parser.add_argument("--remote", type=str, default=None, help=argparse.SUPPRESS)
    parser.add_argument("submission_dir")
    parser.add_argument("games_dir")
    parser.add_argument("output", nargs='?', default="stats.json")
    parser.add_argument("--nb-processes", type=int)
    parser.add_argument("--debug", action="store_true")
    parser.add_argument("-v", "--verbose", action="store_true")
    args = parser.parse_args()

    if os.path.isdir(args.submission_dir) and "custom_agent.py" not in os.listdir(args.submission_dir):
        msg = ("Can't find 'custom_agent.py'. Make sure all your files are places"
               " at the root of your submission zip file.")
        parser.error(msg)

    metadata = {}
    submission_metadata = os.path.join(args.submission_dir, "metadata")
    if os.path.isdir(args.submission_dir):
        if not os.path.isfile(submission_metadata):
            msg = ("Can't find a 'metadata' file in your submission zip file.")
            parser.error(msg)

        with open(submission_metadata) as f:
            for line in f:
                key, value = line.split(":", 1)
                metadata[key.strip()] = value.strip()

    args.nb_processes = args.nb_processes or metadata.get("nb_processes") or multiprocessing.cpu_count()
    args.nb_processes = int(args.nb_processes)
    if args.debug:
        args.nb_processes = 1
        args.verbose = True

    if args.in_docker:
        args.submission_dir = os.path.abspath(args.submission_dir)
        args.games_dir = os.path.abspath(args.games_dir)
        args.output = os.path.abspath(args.output)

        if args.listen is not None:
            os.chdir(args.submission_dir)  # Needed to load local files (e.g. vocab.txt)
            sys.path = [args.submission_dir] + sys.path  # Prepend to PYTHONPATH
            from custom_agent import CustomAgent
            _serve(CustomAgent, args)
        elif args.remote is not None:
            _run_evaluation(functools.partial(_RemoteAgent, host=args.remote), args)
        else:
            os.chdir(args.submission_dir)  # Needed to load local files (e.g. vocab.txt)
            sys.path = [args.submission_dir] + sys.path  # Prepend to PYTHONPATH
            from custom_agent import CustomAgent
            _run_evaluation(CustomAgent, args)
    else:
        _dockerize(args)

if __name__ == "__main__":
    main()
